<?php

/*
	Duplicate events action
*/
add_filter('post_row_actions', 'swp_lmc_duplicate_events', 10, 2);
function swp_lmc_duplicate_events($actions, $post) {
    if (!current_user_can('edit_posts') ||
		("js_events" != $post->post_type)) {
    	return $actions;
    }

    $actions['duplicate'] = '<a href="admin.php?action=swp_lmc_duplicate_post_as_draft&amp;post='.$post->ID.'&amp;nonce='.wp_create_nonce('lmc-duplicate-post-'.$post->ID).'" title="Duplicate event as draft" rel="permalink">'.__('Duplicate Event', 'lucille-music-core').'</a>';

    return $actions;
}

add_action('admin_action_swp_lmc_duplicate_post_as_draft', "swp_lmc_duplicate_post_as_draft");
function swp_lmc_duplicate_post_as_draft() {
	$nonce = $_REQUEST['nonce'];

	echo "1";

    /* get the original post id */
	$post_id = (isset($_GET['post']) ? intval($_GET['post']) : intval($_POST['post']));

	if(!wp_verify_nonce( $nonce, 'lmc-duplicate-post-'.$post_id) || !current_user_can('edit_posts')) {
		wp_die('Security check failed, please try again.');
	}

    global $wpdb;
    $suffix = '';
    $post_status = 'draft';
    
    if (!(isset($_GET['post']) || isset($_POST['post']) || 
    	(isset($_REQUEST['action']) && ('swp_lmc_duplicate_post_as_draft' == $_REQUEST['action'])))) {
        wp_die('No post to duplicate has been supplied!');
    }
    
	/*original post*/
	$post = get_post($post_id);

    $current_user = wp_get_current_user();
    $new_post_author = $current_user->ID;

    /*check if post data exists*/
	if (!isset($post) || (isset($post) && ($post == null))) {
		wp_die('Could not find original post: '.$post_id);
	}

    /* new post data array */
    $args = array(
         'comment_status' => $post->comment_status,
         'ping_status' => $post->ping_status,
         'post_author' => $new_post_author,
         'post_content' => $post->post_content,
         'post_excerpt' => $post->post_excerpt,
         'post_parent' => $post->post_parent,
         'post_password' => $post->post_password,
         'post_status' => $post_status,
         'post_title' => $post->post_title.$suffix,
         'post_type' => $post->post_type,
         'to_ping' => $post->to_ping,
         'menu_order' => $post->menu_order,
	);

	/*
	* insert the post by wp_insert_post() function
	*/
	$new_post_id = wp_insert_post($args);

    /*get all current post terms ad set them to the new post draft*/
	$taxonomies = get_object_taxonomies($post->post_type);
	if (!empty($taxonomies) && is_array($taxonomies)) {
		foreach ($taxonomies as $taxonomy) {
			$post_terms = wp_get_object_terms($post_id, $taxonomy, array('fields' => 'slugs'));
			wp_set_object_terms($new_post_id, $post_terms, $taxonomy, false);
		}
	}

	/*duplicate all post meta*/
	$post_meta_infos = $wpdb->get_results("SELECT meta_key, meta_value FROM $wpdb->postmeta WHERE post_id=$post_id");
	if (count($post_meta_infos)!=0) {
		$sql_query = "INSERT INTO $wpdb->postmeta (post_id, meta_key, meta_value) ";
		foreach ($post_meta_infos as $meta_info) {
			$meta_key = sanitize_text_field($meta_info->meta_key);
			$meta_value = addslashes($meta_info->meta_value);
			$sql_query_sel[]= "SELECT $new_post_id, '$meta_key', '$meta_value'";
		}
		$sql_query.= implode(" UNION ALL ", $sql_query_sel);
		$wpdb->query($sql_query);
	}

    /*redirect*/
    $returnpage = $post->post_type != 'post' ? '?post_type='.$post->post_type : ''; 
	wp_redirect(admin_url('edit.php'.$returnpage));

    exit;
}