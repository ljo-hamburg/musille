<?php

function LMC_SWP_render_select_options($options, $selected) {
	if (empty($selected)) {
		return;
	}

	foreach($options as $key => $value) {
		if ($value == $selected) {
			?>
			<option value="<?php echo esc_attr($value); ?>" selected="selected"> <?php echo esc_attr($key); ?> </option>
			<?php
		} else {
			?>
			<option value="<?php echo esc_attr($value); ?>"> <?php echo esc_attr($key); ?> </option>
			<?php
		}
	}
}

function LMC_SWP_get_recaptcha_sitekey() {
	$plugin_opts = get_option('LMC_plugin_options');

	if (!empty($plugin_opts['swp_recaptcha_site_key']) && !empty($plugin_opts['swp_recaptcha_secret_key'])) {
		return $plugin_opts['swp_recaptcha_site_key'];
	}

	return "";
}

function LUCILLE_SWP_check_recaptcha($remote_addr, $response) {
	$plugin_opts = get_option( 'LMC_plugin_options' );

	if (!empty($plugin_opts['swp_recaptcha_site_key']) && !empty($plugin_opts['swp_recaptcha_secret_key'])) {

		$secret = $plugin_opts['swp_recaptcha_secret_key'];
		$recaptcha = new ReCaptcha($secret);
		$resp = $recaptcha->verify($response, $remote_addr);
		if (!$resp->isSuccess()) {
			return false;
		}
	}

	return true;
}

function lmc_is_woocommerce_active() {
	if (class_exists('woocommerce')) {
		return true;
	}

	return false;
}

function lmc_products_dropdown($selectName, $selected_item) {
	$args = array(
				'numberposts'		=> 	-1,
				'orderby'          => 'post_date',
				'order'            => 'DESC',
				'post_type'        => 'product',
				'post_status'      => 'publish'
			);	
	$product_posts = get_posts($args);
	
	$products_dropdown = array();
	$str_none = esc_html__("None", "lucille-music-core");
	$products_dropdown[$str_none] = 0;

	/*key(post_id)	=> value(post_name)*/
	foreach($product_posts as $single_product) {
		$my_post_id = $single_product->ID;
		$my_post_name = $single_product->post_title;
		
		$products_dropdown[$my_post_name] = $my_post_id;
	}
	wp_reset_postdata();

	if (empty($selected_item)) {
		$selected_item = esc_html__("None", "lucille-music-core");
	}
	?>

	<select name="<?php echo esc_attr($selectName); ?>">
		<?php LMC_SWP_render_select_options($products_dropdown, $selected_item); ?>
	</select>

	<?php
}