<?php

require_once(CDIR_PATH."/assets/ReCaptcha/RequestMethod.php");
require_once(CDIR_PATH."/assets/ReCaptcha/RequestMethod/Post.php");
require_once(CDIR_PATH."/assets/ReCaptcha/RequestParameters.php");
require_once(CDIR_PATH."/assets/ReCaptcha/Response.php");
require_once(CDIR_PATH."/assets/ReCaptcha/ReCaptcha.php");

?>